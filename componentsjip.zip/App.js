
// import { useState } from 'react';
import './App.css';
// import About from './components/About';
import Navbar from './components/Navbar';
import Textform1 from './components/Textform1';
import React, { useState } from 'react'



function App() {
  const [mode,setmode] = useState('mode={bg-dark}');

  const Togglemode = ()=>{
    if(mode==='bg-light'){
      setmode = 'bg-dark'
    }

    else{
      setmode = 'bg-light'
    }
  }
  return (
<>

<Navbar title = "Mynewapp" mode = {mode}/>
<div className="container my-3">
<Textform1></Textform1>
</div>




</>
  );
}

export default App;
