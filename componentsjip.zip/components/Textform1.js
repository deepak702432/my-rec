import React, {useState} from 'react'

export default function Textform1(props) {


  const upclick = ()=> {
    let newtext = text.toUpperCase();
    setText(newtext)
  }

  const downclick = ()=> {
    let newtext = text.toLowerCase();
    setText(newtext)
  }

  const count_text = ()=> {
    let newtext = text.length
    setText(newtext)
  }

  const copy_text = ()=> {
    let var1 = document.getElementById("exampleFormControlTextarea1");
    var1.select();
    navigator.clipboard.writeText(var1.value);
  }



 





  const handleonchnage = (event)=> {
    setText(event.target.value)
  }





  const [text,setText] = useState("Enter text");
  return (
    <div>
        <div className="mb-3">

  <textarea className="form-control" value={text} onChange={handleonchnage} id="exampleFormControlTextarea1" rows="8"></textarea>
       </div>
       <button type="button" className="btn btn-primary m-1" onClick={upclick}>Convert to uppercase</button>
      
       <button type="button" className="btn btn-primary m-1" onClick={downclick}>Convert to lowercase</button>

       <button type="button" className="btn btn-primary m-1" onClick={count_text}>length of Text</button>

       <button type="button" className="btn btn-primary m-1" onClick={copy_text}>copy</button>
    </div>


  )
}
